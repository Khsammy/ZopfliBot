const config = {
  host: "http://127.0.0.1",
  port: "5000",
};

module.exports = config;
