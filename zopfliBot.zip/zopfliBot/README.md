
Build a Telegram Bot using any nodejs npm package that can
1. Reply with weather of london when you ask it (you must use a weather api)
2. Convert naira to usd and vice versa (you can store the conversion rate on redis)
3. create Api's on the server to get and  update the conversion rates on the redis


use this npm library https://www.npmjs.com/package/node-telegram-bot-api

